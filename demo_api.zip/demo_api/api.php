<?php

header('content-type: application/json'); //jason  type

$request = $_SERVER['REQUEST_METHOD']; //=== 'POST'

switch ($request) {
    case 'GET':
        getMethod();
        break;
    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);
        postMethod($data);
        break;
    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);
        putMethod($data);
        break;
    case 'DELETE':
        $data = json_decode(file_get_contents('php://input'), true);
        deleteMethod($data);
        break;
}

function getMethod() {
    include './connect.php';
    $sql = "SELECT * FROM tb_test";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        $rows = array();
        while ($r = mysqli_fetch_assoc($result)) {
            $rows['result'][] = $r;
        }
        echo json_encode($rows);
    } else {
        echo'{"result":"No data found"}';
    }
}

function postMethod($data) {
    include './connect.php';
    $name = $data['name'];
    $email = $data['email'];
    $sql = "INSERT INTO tb_test(name,email,created_at) VALUES('$name','$email',NOW())";

    if (mysqli_query($conn, $sql)) {
        echo'{"result":"data insert Successsfully"}';
    } else {
        die("insert failed: " . $conn->connect_error);
    }
}

//update
function putMethod($data) {
    include './connect.php';
    $id = $data['id'];
    $name = $data['name'];
    $email = $data['email'];
    $sql = "UPDATE tb_test SET name='$name', email='$email' where id='$id' ";

    if (mysqli_query($conn, $sql)) {
        echo "data update Successsfully";
    } else {
        die("update failed: " . $conn->connect_error);
    }
}

//update
function deleteMethod($data) {
    include './connect.php';
    $id = $data['id'];
    $name = $data['name'];
    $email = $data['email'];
    $sql = "DELETE  from tb_test where  id='$id' ";

    if (mysqli_query($conn, $sql)) {
        echo "data delete Successsfully";
    } else {
        die("delete failed: " . $conn->connect_error);
    }
}

//
//switch ($request) {
//    case 'GET':
//        echo'{"name":"get..rumman"}';
//        break;
//    case 'POST':
//        echo'{"name":"post..rumman"}';
//        break;
//    case 'PUT':
//        echo'{"name":"put..rumman"}';
//        break;
//    case 'DELETE':
//        echo'{"name":"delete..rumman"}';
//        break;
//}
?>